package com.example.restservice;

public record Commentaire(long id_image,long id, String pseudo, String contenu) { }